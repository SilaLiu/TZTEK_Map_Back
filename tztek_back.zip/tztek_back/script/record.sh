#! /bin/bash
rosbag record --split --size=2048 --buffsize=1024 $(cat ./Data_collection.txt)
