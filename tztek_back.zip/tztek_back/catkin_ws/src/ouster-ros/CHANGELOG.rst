=========
Changelog
=========

[Unreleased]
============
* Update LICENSE installation.

[20221004]
==========

ouster_ros
----------
* Moved ouster-ros into separate repo
* Refresh the docker file

ouster_sdk
----------
* Removed ouster_ros
